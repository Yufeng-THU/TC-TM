#########################
## TC-TM(Toy model)
## Supplement file
#########################


##########
### Definitions of Environmental fields

Latname = c(); Lonname = c()
for(i in c(90:-90)){ Latname = c(Latname,paste('Lat_',i,sep = '')) }
for(i in c(0:180,-179:-1)){ Lonname = c(Lonname,paste('Lon_',i,sep = '')) }
# define array with each month+State
data_array = array(rep(0,181*360*13),dim = c(181,360,13),dimnames = list(Latname, Lonname, c(month.abb,'State')))

# Define MDR
for(month in 1:12){
  data_temp_month = subset(data_temp, Month == month)
  for(i in 1:length(data_temp_month$LAT)){
    lat_name = paste('Lat_',data_temp_month$LAT[i],sep = '')
    lon_name = paste('Lon_',data_temp_month$LON[i],sep = '')
    data_array[lat_name,lon_name,month] = 1
  }
  Count_month = 1 
  while(Count_month != sum(data_array[,,month])){
    Count_month = sum(data_array[,,month])
    for(i in 2:180){
      for(j in 3:358){
        if(i < 61 | i > 121){ data_array[i,j,month] = 0;next }
        if(i >= 61 & i <= 121){
          if(i >= 86 & i <= 96) { data_array[i,j,month] = 0;next }
          if(sum(data_array[(i-1):(i+1),(j-1):(j+1),month])>=4) {data_array[i,j,month] = 1}
        }
      }
    }
    print(paste(month,Count_month))
  }
  # connect MDR area
  for(i in 2:180){
    for(j in 3:358){
      if(i < 61 | i > 121){ data_array[i,j,month] = 0;next }
      if(i >= 61 & i <= 121){
        if(i >= 86 & i <= 96) { data_array[i,j,month] = 0;next }
        if(sum(data_array[(i-1):(i+1),(j-1):(j+1),month])>7) {data_array[(i-1):(i+1),(j-1):(j+1),month] = 1}
      }
    }
  }
  # Excluding outliers
  for(i in 61:121){
    for(j in 3:358){
      if(sum(data_array[(i-2):(i+2),(j-2):(j+2),month])==1){data_array[i,j,month] = 0}
    }
  }
}

##########
### Function definition

### Recovery of environmental fileds
Renew = function(Delete_lat, Delete_lon){
  Delete_lat = round(Delete_lat,0)
  Delete_lon = round(Delete_lon,0)
  for(i_lat in (Delete_lat-Dist_R0):(Delete_lat+Dist_R0)){
    for(j_lon in (Delete_lon-Dist_R0):(Delete_lon+Dist_R0)){
      if(((i_lat-Delete_lat)^2 + (j_lon-Delete_lon)^2) <= (Dist_R0^2 + 1)){
        i_row = 91 - i_lat
        if(j_lon>180){j_lon = j_lon - 360}
        if(j_lon<(-180)){j_lon = j_lon + 360}
        if(j_lon>=0){j_col = j_lon + 1}
        if(j_lon< 0){j_col = j_lon + 361}
        data_array[i_row,j_col,'State'] <<- 1 & data_array[i_row,j_col,INI]
      }
    }
  }
}

### Influence of TC in the toy model
Cover = function(Cover_lat, Cover_lon){
  Cover_lat = round(Cover_lat,0)
  Cover_lon = round(Cover_lon,0)
  # 输入需要覆盖的经纬坐标
  for(i_lat in (Cover_lat-Dist_R0):(Cover_lat+Dist_R0)){
    for(j_lon in (Cover_lon-Dist_R0):(Cover_lon+Dist_R0)){
      # 经纬坐标遍历周围网格点
      # 如果距离在园内，则找到网格的横纵坐标，覆盖
      if(((i_lat-Cover_lat)^2 + (j_lon-Cover_lon)^2) <= (Dist_R0^2 + 1)){
        i_row = 91 - i_lat
        if(j_lon>180){j_lon = j_lon - 360}
        if(j_lon<(-180)){j_lon = j_lon + 360}
        if(j_lon>=0){j_col = j_lon + 1}
        if(j_lon< 0){j_col = j_lon + 361}
        data_array[i_row,j_col,'State'] <<- 0
      }
    }
  }
}

### TC Basin
BASIN = function(LAT,LON){
  if(LAT >= 0){
    if(LON >= 100){basin = 'WNP'}
    if(LON >= 0 & LON < 100){basin = 'NIO'}
    if(LON < -100){basin = 'ENP'}
    if(LON > -70 & LON < 0){basin = 'NATL'}
    if(LON >= -100 & LON <= -70){
      if(LAT+5/6*LON+175/3 > 0){basin = 'NATL'}
      if(LAT+5/6*LON+175/3 <= 0){basin = 'ENP'}
    }
  }
  if(LAT < 0){
    if(LON >= 0 & LON < 90){basin = 'SIO'}
    if(LON >= 90 & LON < 160){basin = 'AUS'}
    if(LON >= 160){basin = 'SPAC'}
    if(LON < 0){basin = 'SPAC'}
  }
  return(basin)
}

