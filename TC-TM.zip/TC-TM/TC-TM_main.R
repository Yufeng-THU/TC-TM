#########################
## TC-TM(Toy model)
## Main code file
#########################

###### Sensitivity test (490 tests)

# Time_Re: Recovery Time
# Dist_R0: Influencing Radius
# SPEED: Speed Coefficient

Test = data.frame(Time_Re=rep(c(6,10,13,15,17,19,21,23,26,30),each=49),
                  Dist_R0=rep(c(4,6,8,10,12,14,16),each=7,times=10),
                  SPEED=rep(c(0.4,0.6,0.8,1,1.2,1.4,1.6),times=70))

for(row in 1:length(Test[,1])){
  
  ### Initialization
  Time_Re = Test[row,1]
  Dist_R0 = Test[row,2]
  SPEED   = Test[row,3]
  Dist_Gene = 4   # for calculating the survival rate
  Days_sum = 1826 # for 5 years
  
  rm(data_tf,data_tf_detail);gc()

  ## Data table for each TC
    # Number    : No. for each TC
    # Day_gene  : The days of TC genesis
    # Hour_gene : The time of TC genesis
    # Live      : logical parameter for whether TC is active
    # Day_lysis : The days of TC lysis
    # Hour_lysis: The time of TC lysis
    # Lat_gene  : The Latitude of TC genesis 
    # Lon_gene  : The longitude of TC genesis
    # Lat_lysis : The Latitude of TC lysis 
    # Lon_lysis : The longitude of TC lysis
    # Basin     : TC active basin
    # Date      : The date of TC genesis(first day for 2021/1/1)
    # Lifetime  : TC lifetime
  N_tf=2000
  Num = 0
  data_tf = data.frame()
  data_tf[1:N_tf,1:13] = 0
  colnames(data_tf) = c('Number','Day_gene','Hour_gene','Live','Day_lysis','Hour_lysis',
                        'Lat_gene','Lon_gene','Lat_lysis','Lon_lysis','Basin','Date','Lifetime')

  ## Data table for each step (6 hour, optional)
  # N_detail=100000
  # Num_detail = 0
  # data_tf_detail = data.frame()
  # data_tf_detail[1:N_detail,1:13] = 0
  # colnames(data_tf_detail) = c('Number','Number_count','Day','Hour','Lat','Lon',
  #                              'Live','Basin','Date','Speed','Speed_delta','Direct','Direct_delta')
  
  for(DAY in 1:Days_sum){
    # The month of each run
    MONTH = as.numeric(substr(as.Date(DAY-1,origin ='2021-01-01'),6,7))
    INI = month.abb[MONTH] # Month.abb
    
    # Initialization for each month (1st)
    if(as.numeric(substr(as.Date(DAY-1,origin ='2021-01-01'),9,10)) == 1){
      # update for environmental conditions
      data_array[,,'State'] = data_array[,,INI]
      # effect of existing TCs
      data_temp = subset(data_tf_detail, (DAY-Day) < Time_Re & Day != 0)
      if(length(data_temp[,1]) > 0){
        for(line in 1:length(data_temp[,1])){
          Cover(data_temp$Lat[line], data_temp$Lon[line])
        }
      }
    }
  
    # Initialization for each day
      # Recovery after recovery time
    data_temp = subset(data_tf_detail, (DAY-Day) == Time_Re & Day != 0)
    if(length(data_temp[,1]) > 0){
      for(line in 1:length(data_temp[,1])){
        Renew(data_temp$Lat[line], data_temp$Lon[line])
      }
    }
      # effect of existing TCs
    data_temp = subset(data_tf_detail, (DAY-Day) < Time_Re & Day != 0)
    if(length(data_temp[,1]) > 0){
      for(line in 1:length(data_temp[,1])){
        Cover(data_temp$Lat[line], data_temp$Lon[line])
      }
    }
    
  ## Every 6 hours
    for(HOUR in 1:4){
      
      ### [First part] TC genesis
      flag = 0;i=1;j=1
      if(sum(data_array[,,'State']) > 0){
        
        area = which(data_array[,,'State'] == 1, arr.ind = T)
        area_line = sample(1:dim(area)[1],1)
        i = area[area_line,1]; j = area[area_line,2]
        
        for(i_gene in (i-Dist_Gene):(i+Dist_Gene)){
          for(j_gene in (j-Dist_Gene):(j+Dist_Gene)){
            if((i_gene - i)^2 + (j_gene - j)^2 <= Dist_Gene^2){
              flag = flag + data_array[i_gene,j_gene,'State']
        } } }
        Survival_rate = 0
        # The surrounding area within 4 degrees has 49 grids
        if(flag/49 > 0.5){Survival_rate = 1} 
      }
      
      if(Survival_rate == 1){
        Num = Num + 1
        Num_detail = Num_detail + 1
        
        data_tf$Number[Num]  =  Num
        data_tf$Day_gene[Num]  =  DAY
        data_tf$Hour_gene[Num]  =  HOUR
        data_tf$Live[Num]  =  1
  
        # The transformation between latitude (longitude) and rows (columns)
        data_tf$Lat_gene[Num]  =  91 - area[area_line,1] + runif(1,min = -0.4,max = 0.4)
        if(j < 182) { data_tf$Lon_gene[Num]  =  area[area_line,2] - 1 + runif(1,min = -0.4,max = 0.4)}
        if(j > 181) { data_tf$Lon_gene[Num]  =  area[area_line,2] - 361 + runif(1,min = -0.4,max = 0.4)}
        if(data_tf$Lon_gene[Num] >= 180){data_tf$Lon_gene[Num] = -180}
        data_tf$Basin[Num] =  BASIN(data_tf$Lat_gene[Num],data_tf$Lon_gene[Num])
        data_tf$Date[Num] = as.character(as.Date(DAY-1,origin ='2021-01-01'))
        
        data_tf_detail$Number[Num_detail]  =  Num
        data_tf_detail$Number_count[Num_detail]  =  1
        data_tf_detail$Day[Num_detail]  =  DAY
        data_tf_detail$Hour[Num_detail]  =  HOUR
        data_tf_detail$Lat[Num_detail]  =  data_tf$Lat_gene[Num]
        data_tf_detail$Lon[Num_detail]  =  data_tf$Lon_gene[Num]
        data_tf_detail$Live[Num_detail]  =  1
        data_tf_detail$Basin[Num_detail]  =  data_tf$Basin[Num]
        data_tf_detail$Date[Num_detail] =  data_tf$Date[Num]
        
        # Initial parameters from sampling
        mean_vector = c(data_array_move[(data_tf$Lat_gene[Num] %/% 3 + 31),(data_tf$Lon_gene[Num] %/% 3 + 61),c('Speed_mean','Direct_mean')])
        sigma_matrix = matrix(data_array_move[(data_tf$Lat_gene[Num] %/% 3 + 31),(data_tf$Lon_gene[Num] %/% 3 + 61),c('Speed_var','SpeedDirect_cov','SpeedDirect_cov','Direct_var')],nrow = 2)
        
        flag = 0
        temp = rmvnorm(1,mean_vector,sigma_matrix)
        if(data_tf_detail$Lat[Num_detail] > 0){
          while(abs(temp[2]) > 90){
            flag = flag + 1
            if(flag > 10){break}
            temp = rmvnorm(1,mean_vector,sigma_matrix)
          }
          data_tf_detail$Direct[Num_detail] =temp[2]
          data_tf_detail$Speed[Num_detail] = temp[1]
        }
        if(data_tf_detail$Lat[Num_detail] < 0){
          while(abs(temp[2]) < 90){
            flag = flag + 1
            if(flag > 10){break}
            temp = rmvnorm(1,mean_vector,sigma_matrix)
          }
          data_tf_detail$Direct[Num_detail] =temp[2]
          data_tf_detail$Speed[Num_detail] = temp[1]
        }
  
        # Initial changes of parameters from sampling
        data_normal = data_array_move[(data_tf_detail$Lat[Num_detail] %/% 3 + 31),(data_tf_detail$Lon[Num_detail] %/% 3 + 61),]
        
        mean_s = data_normal[4] + data_normal[7]/data_normal[5]*(data_tf_detail$Speed[Num_detail] - data_normal[3])
        if(is.infinite(mean_s) | is.nan(mean_s) | mean_s<0){ mean_s = 0}
        var_s = data_normal[6] - data_normal[7]/data_normal[5]*data_normal[7]
        if(is.infinite(var_s) | is.nan(var_s) | var_s<0){ var_s = 0}
        data_tf_detail$Speed_delta[Num_detail] = rnorm(n=1, mean = mean_s, sd = sqrt(var_s))
        
        mean_d = data_normal[9] + data_normal[12]/data_normal[10]*(data_tf_detail$Direct[Num_detail] - data_normal[8])
        if(is.infinite(mean_d) | is.nan(mean_d) | mean_d<0){ mean_d = 0}
        var_d = data_normal[11] - data_normal[12]/data_normal[10]*data_normal[12]
        if(is.infinite(var_d) | is.nan(var_d) | var_d<0){ var_d = 0}
        
        if(data_tf_detail$Lat[Num_detail] > 0){
          for(i in 1:5){
            data_tf_detail$Direct_delta[Num_detail] = rnorm(n=1, mean = mean_d, sd = sqrt(var_d))
            if(abs(data_tf_detail$Direct_delta[Num_detail] + data_tf_detail$Direct[Num_detail])<120){break}
          }
        }
        if(data_tf_detail$Lat[Num_detail] < 0){
          for(i in 1:5){
            data_tf_detail$Direct_delta[Num_detail] = rnorm(n=1, mean = mean_d, sd = sqrt(var_d))
            if(abs(data_tf_detail$Direct_delta[Num_detail] + data_tf_detail$Direct[Num_detail])>60){break}
          }
        }
        Cover(data_tf$Lat_gene[Num],data_tf$Lon_gene[Num])
        }
      
      ### [Second part] TC movement
      LIVE = data_tf$Number[data_tf$Live == 1] # TCs active
      temp = data_tf$Number[(data_tf$Day == DAY) & (data_tf$Hour == HOUR)] # excluding TC genesis at this time
      if(length(temp)>0){LIVE = LIVE[-which(LIVE==temp)]}
      
      # Movement for TCs active
      for(live in LIVE){
        # Update the data table
        Num_detail = Num_detail + 1
        data_tf_detail$Number[Num_detail]  =  live
        data_tf_detail$Number_count[Num_detail] = length(data_tf_detail$Number[data_tf_detail$Number==live])
        data_tf_detail$Day[Num_detail]  =  DAY
        data_tf_detail$Hour[Num_detail]  =  HOUR
        data_tf_detail$Live[Num_detail]  =  1
        
        lat_pre = data_tf_detail$Lat[data_tf_detail$Number == live & data_tf_detail$Number_count == data_tf_detail$Number_count[Num_detail] - 1]
        lon_pre = data_tf_detail$Lon[data_tf_detail$Number == live & data_tf_detail$Number_count == data_tf_detail$Number_count[Num_detail] - 1]
        speed_pre = data_tf_detail$Speed[data_tf_detail$Number == live & data_tf_detail$Number_count == data_tf_detail$Number_count[Num_detail] - 1]
        direct_pre = data_tf_detail$Direct[data_tf_detail$Number == live & data_tf_detail$Number_count == data_tf_detail$Number_count[Num_detail] - 1]
        speed_delta_pre = data_tf_detail$Speed_delta[data_tf_detail$Number == live & data_tf_detail$Number_count == data_tf_detail$Number_count[Num_detail] - 1]
        direct_delta_pre = data_tf_detail$Direct_delta[data_tf_detail$Number == live & data_tf_detail$Number_count == data_tf_detail$Number_count[Num_detail] - 1]
        
        # movement step
        data_tf_detail$Lat[Num_detail]  = destPoint(c(lon_pre,lat_pre), direct_pre+direct_delta_pre, SPEED*(speed_pre+speed_delta_pre)*60*60*6)[2]
        data_tf_detail$Lon[Num_detail]  = destPoint(c(lon_pre,lat_pre), direct_pre+direct_delta_pre, SPEED*(speed_pre+speed_delta_pre)*60*60*6)[1]
        if(data_tf_detail$Lon[Num_detail] >= 180){data_tf_detail$Lon[Num_detail] = -180}
        
        data_tf_detail$Speed[Num_detail] = speed_pre+speed_delta_pre
        data_tf_detail$Direct[Num_detail] = direct_pre+direct_delta_pre
        data_tf_detail$Basin[Num_detail]  =  BASIN(data_tf_detail$Lat[Num_detail],data_tf_detail$Lon[Num_detail])
        data_tf_detail$Date[Num_detail] =  as.character(as.Date(DAY-1,origin ='2021-01-01'))
        
        # Change rate of parameters
        data_normal = data_array_move[(data_tf_detail$Lat[Num_detail] %/% 3 + 31),(data_tf_detail$Lon[Num_detail] %/% 3 + 61),]
        
        mean_s = data_normal[4] + data_normal[7]/data_normal[5]*(data_tf_detail$Speed[Num_detail] - data_normal[3])
        if(is.infinite(mean_s) | is.nan(mean_s) | mean_s<0){ mean_s = 0}
        var_s = data_normal[6] - data_normal[7]/data_normal[5]*data_normal[7]
        if(is.infinite(var_s) | is.nan(var_s) | var_s<0){ var_s = 0}
        data_tf_detail$Speed_delta[Num_detail] = rnorm(n=1, mean = mean_s, sd = sqrt(var_s))
        
        mean_d = data_normal[9] + data_normal[12]/data_normal[10]*(data_tf_detail$Direct[Num_detail] - data_normal[8])
        if(is.infinite(mean_d) | is.nan(mean_d) | mean_d<0){ mean_d = 0}
        var_d = data_normal[11] - data_normal[12]/data_normal[10]*data_normal[12]
        if(is.infinite(var_d) | is.nan(var_d) | var_d<0){ var_d = 0}
        
        if(data_tf_detail$Lat[Num_detail] > 0){
          for(i in 1:5){
            data_tf_detail$Direct_delta[Num_detail] = rnorm(n=1, mean = mean_d, sd = sqrt(var_d))
            if(abs(data_tf_detail$Direct_delta[Num_detail] + data_tf_detail$Direct[Num_detail])<135){break}
          }
        }
        if(data_tf_detail$Lat[Num_detail] < 0){
          for(i in 1:5){
            data_tf_detail$Direct_delta[Num_detail] = rnorm(n=1, mean = mean_d, sd = sqrt(var_d))
            if(abs(data_tf_detail$Direct_delta[Num_detail] + data_tf_detail$Direct[Num_detail])>45){break}
          }
        }
        data_temp = subset(data_tf_detail, Number == live & (DAY-Day) < Time_Re)
        if(length(data_temp[,1]) > 0){
          for(line in 1:length(data_temp[,1])){
            Cover(data_temp$Lat[line], data_temp$Lon[line])
          }
        }
        
        ### [Third part] TC lysis
        Lysis = data_array_move[(data_tf_detail$Lat[Num_detail] %/% 3 + 31),(data_tf_detail$Lon[Num_detail] %/% 3 + 61),'Lysis']
        if(runif(1) <= Lysis){
          data_tf_detail$Speed_delta[Num_detail] = 0
          data_tf_detail$Direct_delta[Num_detail] = 0
          data_tf_detail$Live[Num_detail] = 0
          data_tf$Live[data_tf$Number == live] = 0
          data_tf$Lifetime[data_tf$Number == live] = data_tf_detail$Number_count[Num_detail]/4
        }
      }
    } # End for 6 hours
  } # End fot every DAY
} # End for each run (5 years)

data_tf = subset(data_tf, Number != 0)
# data_tf_detail = subset(data_tf_detail, Number != 0)

# Excluding the duration less than 1 day
Num_missing = data_tf$Number[data_tf$Lifetime<=1]
Num_sample = c(1:Num)[-Num_missing]
if(length(Num_missing)>0){
  data_tf = data_tf[-Num_missing,]
  # data_tf_detail = subset(data_tf_detail, Number %in% Num_sample)
}

### The data for data_tf are summarized in the Simulated Date file
